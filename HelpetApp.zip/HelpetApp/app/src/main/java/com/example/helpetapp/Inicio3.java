package com.example.helpetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Inicio3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio3);

        String inicio = getIntent().getExtras().getString("inicio");

    }
}