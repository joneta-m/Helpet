package com.example.helpetapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class cachorroinfo4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cachorroinfo4);

        Button colab = (Button) findViewById(R.id.colaborador);
        Button ver_info = (Button) findViewById(R.id.btn_info);
        colab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ir_colab = new Intent(v.getContext(),activityColaborador5.class);
                startActivity(ir_colab);
            }
        });
    }

}