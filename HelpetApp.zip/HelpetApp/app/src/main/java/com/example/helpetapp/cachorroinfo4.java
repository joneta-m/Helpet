package com.example.helpetapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class cachorroinfo4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cachorroinfo4);
    }
}