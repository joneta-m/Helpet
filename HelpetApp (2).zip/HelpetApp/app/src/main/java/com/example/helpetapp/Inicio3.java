package com.example.helpetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Inicio3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio3);


        Button agregar_masc = (Button) findViewById(R.id.btn_agregar);
        Button info = (Button) findViewById(R.id.btn_info);

        agregar_masc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mascota = new Intent(v.getContext(),RegistroMascota6.class);
                startActivity(mascota);
            }
        });

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cachorroinfo = new Intent(v.getContext(),cachorroinfo4.class);
                startActivity(cachorroinfo);
            }
        });


    }
}